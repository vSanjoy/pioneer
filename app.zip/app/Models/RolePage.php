<?php
/*
    * Class name    : RolePage
    * Purpose       : Table declaration
    * Author        :
    * Created Date  :
    * Modified date :
*/

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RolePage extends Model
{
    public $timestamps = false;
}